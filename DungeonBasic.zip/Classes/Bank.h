#import "State.h"

@interface Bank : State {
}

+(id)shared;

@end