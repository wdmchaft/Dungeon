#import "cocos2d.h"

@interface RulesLayer : CCLayerColor {	
}

+(CCScene *) scene;

@end
