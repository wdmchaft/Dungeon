#import "State.h"

@interface Space : State {
}

+(id)shared;

@end