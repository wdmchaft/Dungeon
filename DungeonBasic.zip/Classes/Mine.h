#import "State.h"

@interface Mine : State {
}
+(id)shared;

@end
