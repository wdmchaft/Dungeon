#import "State.h"

@interface Room1C : State {
}

+(id)shared;

@end