#import "cocos2d.h"

@interface Token : CCSprite {
	
}

@end
