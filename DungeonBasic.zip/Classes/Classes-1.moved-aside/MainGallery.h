#import "State.h"

@interface MainGallery : State {
}

+(id)shared;

@end