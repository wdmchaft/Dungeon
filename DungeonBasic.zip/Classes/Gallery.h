#import "State.h"

@interface Gallery : State {
}

+(id)shared;

@end