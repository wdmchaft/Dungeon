#import "State.h"

@interface Home : State {
}

+(id)shared;

@end
