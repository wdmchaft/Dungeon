#import "cocos2d.h"

@interface MenuLayer : CCLayerColor {
}

+(CCScene *) scene;

@end
