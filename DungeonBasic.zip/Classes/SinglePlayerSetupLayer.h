#import "cocos2d.h"

@interface SinglePlayerSetupLayer : CCLayerColor {
}

@end
