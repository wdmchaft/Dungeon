#import "State.h"

@interface Room1A : State {
}

+(id)shared;

@end