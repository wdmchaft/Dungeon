#import "State.h"

@interface Room1B : State {
}

+(id)shared;

@end