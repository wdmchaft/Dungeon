//
//  main.m
//  DungeonBasic
//
//  Created by Kimberlee Linder on 3/21/12.
//  Copyright Loft 2012. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
	NSAutoreleasePool *pool = [NSAutoreleasePool new];
	int retVal = UIApplicationMain(argc, argv, nil, @"DungeonBasicAppDelegate");
	[pool release];
	return retVal;
}
